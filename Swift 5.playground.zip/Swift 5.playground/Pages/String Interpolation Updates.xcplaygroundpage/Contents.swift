//: [Previous Topic](@previous)       [Next Topic](@next)
//: # String Interpolation Updates

import Foundation

let language = "Swift"

// Swift  4.2
//let languageSegment = String(stringInterpolationSegment: language)
//let space = " "
//let spaceSegment = String(stringInterpolationSegment: space)
//let version = 4.2
//let versionSegment = String(stringInterpolationSegment: version)
//let string = String(stringInterpolation: languageSegment, spaceSegment, versionSegment)

//: Swift 5.0
var interpolation = DefaultStringInterpolation(literalCapacity: 7, interpolationCount: 1)
interpolation.appendLiteral(language)
let space = " "
interpolation.appendLiteral(space)
let version = 5
interpolation.appendInterpolation(version)
let string = String(stringInterpolation: interpolation)
