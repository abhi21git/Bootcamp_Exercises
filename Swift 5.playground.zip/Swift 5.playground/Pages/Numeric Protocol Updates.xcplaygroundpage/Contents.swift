//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Numeric Protocol Updates

import Foundation

//: ## Numeric Protocol Updates

struct Vector {
    let x, y: Int
    
    init(_ x: Int, _ y: Int) {
        self.x = x
        self.y = y
    }
}
// NOTE: while initialising your struct with init(_:_:) IntegerLiteral is required
//       to conform Vector to ExpressibleByIntegerLiteral as a requirement for Numeric conformance.

//: ## AdditiveArithmetic

extension Vector: AdditiveArithmetic {
    static var zero: Vector {
        return Vector(0, 0)
    }
    
    static func +(lhs: Vector, rhs: Vector) -> Vector {
        return Vector(lhs.x + rhs.x, lhs.y + rhs.y)
    }
    
    static func +=(lhs: inout Vector, rhs: Vector) {
        lhs = lhs + rhs
    }
    
    static func -(lhs: Vector, rhs: Vector) -> Vector {
        return Vector(lhs.x - rhs.x, lhs.y - rhs.y)
    }
    
    static func -=(lhs: inout Vector, rhs: Vector) {
        lhs = lhs - rhs
    }
}
//: Swift 5 implements AdditiveArithmetic for vectors

//: ## CustomStringConvertible

extension Vector: CustomStringConvertible {
    var description: String {
        return "(\(x) \(y))"
    }
}

var first = Vector(1, 2)
let second = Vector(3, 4)
let third = first + second
first += second
let fourth = first - second
first -= second
