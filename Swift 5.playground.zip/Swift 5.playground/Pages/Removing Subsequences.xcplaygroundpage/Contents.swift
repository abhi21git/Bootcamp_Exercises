//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Removing Subsequences

import Foundation

extension Sequence {
    func remove(_ s: String) -> [Element] {
        guard let n = Int(s) else {
            return dropLast()
        }
        return dropLast(n)
    }
}

let sequence = [5, 2, 7, 4]

sequence.remove("2")
sequence.remove("two")

//:In Swift 4 remove(_:) drops the last n elements from the sequence if s is an Int or the last element
//:In Swift 5 remove(_:) returns [Element] since dropLast() and dropLast(_:) return [Element]
