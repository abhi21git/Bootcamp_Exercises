//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Adding Result to the Standard Library
//: Swift 5 adds Result to the standard library which has 

import Foundation

enum ConnectionError: Error {
    case noNetwork, noDatabase
}

let networkSuccess = Result<String, ConnectionError>.success("Network connected!")
let databaseSuccess = Result<String, ConnectionError>.success("Database connected!")

let networkFailure = Result<String, ConnectionError>.failure(.noNetwork)
let databaseFailure = Result<String, ConnectionError>.failure(.noDatabase)

let sameSuccess = networkSuccess == databaseSuccess
let sameFailure = networkFailure == databaseFailure

let success: Set = [networkSuccess, databaseSuccess]
let failure: Set = [networkFailure, databaseFailure]

let successDictionary = [networkSuccess: try! networkSuccess.get(), databaseSuccess: try! databaseSuccess.get()]
let failureDictionary = [networkFailure: ConnectionError.noNetwork, databaseFailure: ConnectionError.noDatabase]

//: Here is a demo code with how and where to use it.
/*
 func fetchPosts(url: URL, completion: @escaping (Result<[Post],NetworkError>) -> Void) {
 
 URLSession.shared.dataTask(with: url) { data, response, error in
 
     guard let data = data, error == nil else {
        if let error = error as NSError?, error.domain == NSURLErrorDomain {
            completion(.failure(.domainError))
        }
        return
     }
 
     do {
        let posts = try JSONDecoder().decode([Post].self, from: data)
        completion(.success(posts))
     } catch {
        completion(.failure(.decodingError))
     }
 
 }.resume()
 
 fetchPosts(url: url) { result in
     switch result {
     case .success(let posts):
        print(posts)
     case .failure:
        print("FAILED")
     }
 }
 
*/
