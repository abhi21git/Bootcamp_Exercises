//: [Previous Topic](@previous)       [Next Topic](@next)
//: # New Unicode Scalar Properties

import Foundation

let username = "bond007"
var letters = 0

for item in username.unicodeScalars {
    if item.properties.isAlphabetic {
        letters += 1
    }
}

print("Username has \(letters) letters.")

//:Earlier we need to implement our own logic
