//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Making Codable Ranges

import Foundation

let temperature = 0...10
let encoder = JSONEncoder()
let data = try! encoder.encode(temperature)
let decoder = JSONDecoder()
let temperatureRange = try! decoder.decode(ClosedRange<Int>.self, from: data)
