//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Handling Future Enumeration Cases

import Foundation

enum Post {
    case tutorial, article, podcast, screencast, course
}

func readPost(_ post: Post) -> String {
    switch post {
    case .tutorial:
        return "You are reading a tutorial."
    case .article:
        return "You are reading an article."
    @unknown default:
        return "You are reading a blog post."
    }
}
//: Swift 5 brings @unknown with default case in switch, which will simplu throw warning if your switch isn't exhaustive.

let screencast = Post.screencast
readPost(screencast)
let course = Post.course
readPost(course)
let podcast = Post.podcast
readPost(podcast)
