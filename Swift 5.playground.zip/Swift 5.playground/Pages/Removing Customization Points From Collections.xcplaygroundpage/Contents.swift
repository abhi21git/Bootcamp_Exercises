//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Removing Customization Points From Collections

import Foundation

extension Array {
    var first: Element? {
        return !isEmpty ? self[count - 1] : nil
    }
    
    var last: Element? {
        return !isEmpty ? self[0] : nil
    }
}

let names = ["Cosmin", "Oana", "Sclip", "Nori"]
names.first // "Nori"
names.last // "Cosmin"
