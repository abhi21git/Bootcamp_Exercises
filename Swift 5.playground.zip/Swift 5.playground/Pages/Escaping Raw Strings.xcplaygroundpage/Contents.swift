//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Escaping Raw Strings

import Foundation

/*
//Swift 4.2
let escape = "You use escape sequences for \"quotes\"\\\"backslashes\" in Swift 4.2."
let multiline = """
You use escape sequences for \"\"\"quotes\"\"\"\\\"\"\"backslashes\"\"\"
on multiple lines
in Swift 4.2.
"""
*/
let raw = #"You can create "raw"\"plain" strings in Swift 5."#
print(raw)

let multiline = #"""
You can create """raw"""\""""plain"""" strings
on multiple lines
in Swift 5.
"""#
print(multiline)

let track = "Nothing Else Matters"
print(#"My favorite tune\song is \#(track)."#)

let hashtag = ##"You can use the Swift "hashtag"#swift in Swift 5."##
let versions = "3 3.1 4 4.1 4.2 5"
let range = NSRange(versions.startIndex..., in: versions)
let regex = try! NSRegularExpression(pattern: #"\d\.\d"#)
let minorVersions = regex.matches(in: versions, range: range)
minorVersions.forEach { print(versions[Range($0.range, in: versions)!]) }
