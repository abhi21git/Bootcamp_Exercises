//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Using Variadic Parameters for Enumeration Cases with Associated Values

import Foundation

enum BlogPost {
    case tutorial([String])
    case article([String])
}
