//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Conforming Never to Equatable and Hashable Protocols

import Foundation

enum ConnectionError: Error {
    case noNetwork, noDatabase
}

let alwaysSucceeds = Result<String, Never>.success("Network connected!")
let neverFails = Result<String, Never>.success("Database connected!")

let alwaysFails = Result<Never, ConnectionError>.failure(.noNetwork)
let neverSucceeds = Result<Never, ConnectionError>.failure(.noDatabase)

let sameValue = alwaysSucceeds == neverFails
let sameError = alwaysFails == neverSucceeds

let alwaysSuccess: Set = [alwaysSucceeds, neverFails]
let alwaysFailure: Set = [alwaysFails, neverSucceeds]

let alwaysSuccessDictionary = [alwaysSucceeds: try! alwaysSucceeds.get(), neverFails: try! neverFails.get()]
let alwaysFailureDictionary = [alwaysFails: ConnectionError.noNetwork, neverSucceeds: ConnectionError.noDatabase]

/*:
 In this code, you define connection results that always return values or errors,
 compare them, add them to sets and use them as dictionary keys.
*/
