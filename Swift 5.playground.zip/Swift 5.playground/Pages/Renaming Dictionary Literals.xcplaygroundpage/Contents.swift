//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Renaming Dictionary Literals

import Foundation

let pets: KeyValuePairs = ["dog": "Sclip", "cat": "Peti"]

//:Earlier it was 'DictionaryLiteral' instead of 'KeyValuePairs'
