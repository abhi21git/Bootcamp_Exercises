//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Initializing Literals Through Coercion

import Foundation

let value = UInt64(0xFFFF_FFFF_FFFF_FFFF)
