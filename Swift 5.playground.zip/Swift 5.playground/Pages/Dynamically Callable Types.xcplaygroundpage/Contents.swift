//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Dynamically Callable Types

import Foundation

@dynamicCallable
class DynamicFeatures {
    func dynamicallyCall(withArguments params: [Int]) -> Int? {
        guard !params.isEmpty else {
            return nil
        }
        return params.reduce(0, +)
    }
    
    func dynamicallyCall(withKeywordArguments params: KeyValuePairs<String, Int>) -> Int? {
        guard !params.isEmpty else {
            return nil
        }
        return params.reduce(0) { $1.key.isEmpty ? $0 : $0 + $1.value }
    }
}

let features = DynamicFeatures()
features()
features(3, 4, 5)
features(first: 3, 4, second: 5)
