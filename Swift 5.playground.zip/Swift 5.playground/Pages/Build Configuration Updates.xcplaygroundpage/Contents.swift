//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Build Configuration Updates

import Foundation

let favoriteNumber = 10
var evenNumber = true

#if swift(<5)
evenNumber = favoriteNumber % 2 == 0
#else
evenNumber = favoriteNumber.isMultiple(of: 2)
#endif

#if compiler(<5)
evenNumber = favoriteNumber % 2 == 0
#else
evenNumber = favoriteNumber.isMultiple(of: 2)
#endif

