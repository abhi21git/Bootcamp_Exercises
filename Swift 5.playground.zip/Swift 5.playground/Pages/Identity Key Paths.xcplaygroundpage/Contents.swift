//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Identity Key Paths

import Foundation

class Tutorial {
    let title: String
    let author: String
    
    init(title: String, author: String) {
        self.title = title
        self.author = author
    }
}

var tutorial = Tutorial(title: "What's New in Swift 5?", author: "Abhishek Maurya")
tutorial[keyPath: \.self] = Tutorial(title: "What's New in Swift 5.0 and 5.1?", author: "Abhishek Maurya")
