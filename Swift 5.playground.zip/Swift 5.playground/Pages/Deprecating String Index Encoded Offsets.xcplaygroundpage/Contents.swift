//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Deprecating String Index Encoded Offsets

import Foundation

let swiftVersion = "Swift 5"
let offset = swiftVersion.endIndex.utf16Offset(in: swiftVersion)

