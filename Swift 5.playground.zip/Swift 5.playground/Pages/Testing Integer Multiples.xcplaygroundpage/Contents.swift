//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Testing Integer Multiples

import Foundation

let firstNumber = 8
let secondNumber = 2

if firstNumber.isMultiple(of: secondNumber) {
    print("\(secondNumber) * \(firstNumber / secondNumber) = \(firstNumber)")
}
else {
    print("\(firstNumber) is not multiple of \(secondNumber)")
}
//:Earlier we use % operation to check for zero remainder in Swift 4.2
