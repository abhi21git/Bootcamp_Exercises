//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Flattening Nested Optionals

import Foundation

extension Int {
    enum DivisionError: Error {
        case divisionByZero
    }
    
    func divideBy(_ number: Int) throws -> Int {
        guard number != 0 else {
            throw DivisionError.divisionByZero
        }
        return self / number
    }
}

let number: Int? = 10
let division = try? number?.divideBy(2)
if let division = division {
    print(division)
}
