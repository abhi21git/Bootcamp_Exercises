//: [Previous Topic](@previous)       [Next Topic](@next)
//: # Compacting Dictionaries

import Foundation

let isSwift5 = true
let students = ["Oana": "10", "Nori": "ten"]

if isSwift5 {
    let mapStudents = students.compactMapValues(Int.init)
    print(mapStudents)
}
else {
    let filterStudents = students.mapValues(Int.init)
        .filter { $0.value != nil }
        .mapValues { $0! }
    let reduceStudents = students.reduce(into: [:]) { $0[$1.key] = Int($1.value) }
    print(reduceStudents)
}

//: Swift reduced multiple dictionary passes and makes your code less complicated.
