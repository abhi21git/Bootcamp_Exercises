//: [Previous Topic](@previous)       [Next Topic](@next)
//: # New Character Properties

import Foundation

let id = "ID123"
var digits = 0

for item in id {
    if item.isNumber {
        digits += 1
    }
}

print("Id has \(digits) digits.")

//:Earlier we need to implement our own logic
